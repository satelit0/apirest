export default {
  mongodbURL: "mongodb://localhost:27017/tasksdb"
}